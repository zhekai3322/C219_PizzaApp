import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import './style.css';

// Pizza data
const pizzas = [
  {
    id: 1,
    name: 'Pizza Spinaci',
    image: './pizzas/spinaci.jpg',
    ingredients: 'Tomato, mozarella, spinach, and ricotta cheese',
    price: 10
  },
  {
    id: 2,
    name: 'Pizza Margherita',
    image: './pizzas/margherita.jpg',
    ingredients: 'Tomato, mozarella, and basil',
    price: 12
  }
];

// Header component (L03 Activity 5)
const Header = () => {
  return <h1 style={{ color: "orange", fontSize: "48px", textTransform: "uppercase" }}>ZheKai's Pizza Co.</h1>;
};

// Pizza component
const Pizza = ({ name, image, ingredients, price }) => {
  return (
    <div>
      <img src={image} alt={name} />
      <h2>{name}</h2>
      <p>Ingredients: {ingredients}</p>
      <p>Price: {price}</p>
    </div>
  );
};

// Menu component (L03 Activty 6)
const Menu = () => {
  return (
    <div className="menu">
      <h2>Our Menu</h2>
      {pizzas.map((pizza) => (
        <Pizza key={pizza.id} {...pizza} />
      ))}
    </div>
  );
};

// Footer component
const Footer = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    const hours = currentTime.getHours();
    setIsOpen(hours >= 10 && hours < 22);

    return () => clearInterval(intervalId);
  }, [currentTime]);

  return (
    <footer className="footer">
      {isOpen ? "We’re currently open" : "Sorry we’re closed"}
    </footer>
  );
};


// App component
const App = () => {
  return (
    <div>
      <Header />
      <Menu />
      <Footer />
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById('root'));