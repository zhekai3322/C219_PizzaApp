import React from 'react';
import ReactDOM from 'react-dom';

// Pizza data
const pizzas = [
  {
    id: 1,
    name: 'Pizza Spinaci',
    image: './pizzas/spinaci.jpg',
    ingredients: 'Tomato, mozarella, spinach, and ricotta cheese',
    price: 10
  },
  {
    id: 2,
    name: 'Pizza Margherita',
    image: './pizzas/margherita.jpg',
    ingredients: 'Tomato, mozarella, and basil',
    price: 12
  }
];

// Header component
const Header = () => {
  return <h1>ZheKai's Pizza Co.</h1>;
};

// Pizza component
const Pizza = ({ name, image, ingredients, price }) => {
  return (
    <div>
      <img src={image} alt={name} />
      <h2>{name}</h2>
      <p>Ingredients: {ingredients}</p>
      <p>Price: {price}</p>
    </div>
  );
};

// App component
const App = () => {
  return (
    <div>
      <Header />
      {pizzas.map((pizza) => (
        <Pizza key={pizza.id} {...pizza} />
      ))}
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById('root'));